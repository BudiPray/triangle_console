﻿using System;

namespace TestLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Rectangle Loop");

            int a;
            int i;
            int a1,a2;

            for ( a = 10; a > 0; a--){
                for (i = 1; i <=a; i++){
                    Console.Write(" ");
                }
                for (a1 = 10; a1 >a; a1--){                   
                    Console.Write("o");
                }
                for (a2 = 11; a2 >a; a2--){
                    Console.Write("o");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
